def fun():
    print("To jest funkcja fun().")
    print("Moduł, w tórym się znajduje to", __name__ + '.')
    print('Pakiet w którym się znajduje to ', __package__)
